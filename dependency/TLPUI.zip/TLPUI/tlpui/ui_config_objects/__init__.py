"""Init module for config widgets."""
