"""Init module for TLPUI."""

__version__ = "1.5.0"
